# LockBit-Black-Builder

LockBit30.7z:
- Source: [@ali_qushji](https://twitter.com/ali_qushji)
- Password: dM@iu9&UJB@#G$1HhZAW
- MD5: ecad36ec22515adac1190a6a46c78fb7
- Content:
    - Build (folder):
        - Date: 2022-09-13 16:34 
    - Build.bat:
        - Date: 2022-09-08 17:14
        - MD5: 4e46e28b2e61643f6af70a8b19e5cb1f
    - builder.exe:
        - Date: 2022-09-13 16:31
        - MD5: c2bc344f6dde0573ea9acdfb6698bf4c
    - config.json:
        - Date: 2022-09-08 17:02
        - MD5: a6ba7b662de10b45ebe5b6b7edaa62a9
    - keygen.exe:
        - Date: 2022-09-08 16:58
        - MD5: 71c3b2f765b04d0b7ea0328f6ce0c4e2
- Original links:
    - sendspace.com/file/ncjuyb

LockBit3Builder.7z
- Source: [@protonleaks1](https://twitter.com/protonleaks1)
- Password: !1C!Vk~1i!LW3LR|wgXHC
- MD5: 7db3797ee09aedc1c6ec1389ab199493
- Content:
    - Build (folder):
        - Date: 2022-09-08 18:29
    - Build.bat:
        - Date: 2022-09-08 17:02
        - MD5: 4e46e28b2e61643f6af70a8b19e5cb1f
    - builder.exe:
        - Date: 2022-09-08 18:28
        - MD5: 8c689dc9e82c9356b990d2b67b4943e1
    - config.json:
        - Date: 2022-09-08 17:02
        - MD5: a6ba7b662de10b45ebe5b6b7edaa62a9
    - keygen.exe
        - Date: 2022-09-08 18:25
        - MD5: 5e28c7c900e4dce08366051c22f07f84
- Original links:
  - anonfiles.com/i8fdxf7eyb/LockBit3Builder.7z
  - ufile.io/3j27rije
  - sendspace.com/file/ojoab8
  - gofile.io/d/nfcKZV
